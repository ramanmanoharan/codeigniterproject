<div class="container">

               <?php 
   if($this->session->flashdata('success')){
 ?>
   <div class="alert alert-info"> 
     <?php  echo $this->session->flashdata('success'); ?>

</div>
<?php } ?>
<table class="table table-bodered" style="text-align:center">
	<tr>
		<th>NAME</th>
		<th>EMAIL</th>
		<th>PHONE</th>
		<th>MESSAGE</th>
		<th>EDIT</th>
		<th>DELETE</th>
	</tr>
	<?php
	foreach($data as $value){
	

?>
	<tr>
		<td><?php echo $value->name; ?></td>
		<td><?php echo $value->email; ?></td>
		<td><?php echo $value->phone; ?></td>
		<td><?php echo $value->message; ?></td>
		<td><a href='editdata/<?php echo $value->id; ?>'><button class="btn btn-success">EDIT</button></a></td>
		<td><a href='deletedata/<?php echo $value->id; ?>'><button class="btn btn-warning">DELETE</button></a></td>
	</tr>
	<?php } ?>
</table>
</div>