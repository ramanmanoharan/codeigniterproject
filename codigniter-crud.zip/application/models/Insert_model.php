<?php

class Insert_model extends CI_Model{
	function form_insert($data){
		$this->db->insert('contact', $data);
	}
	function form_update($id, $name, $email, $phone, $message){
		$query = $this->db->query("UPDATE `contact` SET `name`='$name',`email`='$email',`phone`='$phone',`message`='$message' WHERE `id`= '$id'");
	}
	function display_records()
	{
	$query=$this->db->query("select * from contact");
	return $query->result();
	}
	function delete($id)
	{
		$query = $this->db->query("delete  from contact where id='".$id."'");

	}
	function edit($id)
	{
		$query = $this->db->query("select * from contact where id='".$id."'");
		return $query->row_array();
	}
}




?>